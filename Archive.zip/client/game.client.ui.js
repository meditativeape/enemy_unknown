/**
 * Client UI functions
 */ 
 
/* Setup stage and layers. */
var stage = new Kinetic.Stage({
	container: 'container',
	id: 'gameCanvas',
	width: 800,
	height: 600
});

var mapLayer = new Kinetic.Layer(); // layer for background image, hexgrid, and units
var UILayer = new Kinetic.Layer(); // layer for UI elements, such as minimap, buttons, and unit info
var msgLayer = new Kinetic.Layer({listening: false}); // layer for messages, such as start and end message

var gameClientUI = function() {
	// Teams: 0:red, 1:blue, 2:yellow, 3:green
	// Container for all unit images
	this.sprites = [[], [], [], []];
	// Container for all unit cooldown images
	this.cooldown = [[], [], [], []];
	// Get hit images
	this.getHitImgs = {small: [[], [], [], []], big: [[], [], [], []]};
	// Button images
	this.buttonImgs = {lit: {}, unlit: {}};
	this.buttons = {};
	// Flag images
	this.flagImgs = [];
	this.flags = [];
	// Topbar images
	this.topbarImgs = [];
	this.topbar = null;
	// Build unit images
	this.buildUnitImgs = {frame: null, unavailable: [], lit: [], unlit: []};
	this.buildUnit = [];
	this.buildUnitGroup = null;
	// Mark unit images
	this.markUnitImgs = {lit: [], unlit:[]};
	this.markUnit = [];
	this.markUnitGroup = null;
	this.hasLoaded = false;
}

gameClientUI.prototype.loadImage = function(/*string*/ scenario,/*int*/type ) {

	var filesLoaded = 0;
	
	var loadImage = function(url) {
		var img = new Image();
		img.onload = incrementCounter;
		img.src = url;
		return img;
	};
	
	var incrementCounter = function() {
		filesLoaded++;
		if (filesLoaded >= 60) {
			this.hasLoaded = true;
		}
		this.hasLoaded = false;
	}
	// load sprites
	this.background = loadImage("sprites\\bg_grey.jpg");
	this.heartImg = loadImage("sprites\\heart.png");
	this.resourceImg = loadImage("sprites\\resource.png");
	this.flagImg = loadImage("sprites\\tile-flag.png");
	this.thronImg = loadImage("sprites\\thron.png");
	this.whokillswhoImg = loadImage("sprites\\whokillswho2.png");
	this.fogImg = loadImage("sprites\\fog.png");
	this.buttonbarImg = loadImage("sprites\\buttonbar.png");

	this.sprites[0][0] = loadImage("sprites\\vampire6_red.png");
	this.sprites[0][1] = loadImage("sprites\\wolf6_red.png");
	this.sprites[0][2] = loadImage("sprites\\hunter6_red.png");
	this.sprites[0][3] = loadImage("sprites\\zombie6_red.png");
	this.sprites[0][4] = loadImage("sprites\\wizard6_red.png");
	this.sprites[0][5] = loadImage("sprites\\unknown6_red.png");
	
	this.sprites[1][0] = loadImage("sprites\\vampire6_blue.png");
	this.sprites[1][1] = loadImage("sprites\\wolf6_blue.png");
	this.sprites[1][2] = loadImage("sprites\\hunter6_blue.png");
	this.sprites[1][3] = loadImage("sprites\\zombie6_blue.png");
	this.sprites[1][4] = loadImage("sprites\\wizard6_blue.png");
	this.sprites[1][5] = loadImage("sprites\\unknown6_blue.png");

	// load cooldown spritesheets
	this.cooldown[0][0] = loadImage("sprites\\vampire9_red_cd.png");
	this.cooldown[0][1] = loadImage("sprites\\wolf9_red_cd.png");
	this.cooldown[0][2] = loadImage("sprites\\hunter9_red_cd.png");
	this.cooldown[0][3] = loadImage("sprites\\zombie9_red_cd.png");
	this.cooldown[0][4] = loadImage("sprites\\wizard9_red_cd.png");
	this.cooldown[0][5] = loadImage("sprites\\unknown9_red_cd.png");
	
	this.cooldown[1][0] = loadImage("sprites\\vampire9_blue_cd.png");
	this.cooldown[1][1] = loadImage("sprites\\wolf9_blue_cd.png");
	this.cooldown[1][2] = loadImage("sprites\\hunter9_blue_cd.png");
	this.cooldown[1][3] = loadImage("sprites\\zombie9_blue_cd.png");
	this.cooldown[1][4] = loadImage("sprites\\wizard9_blue_cd.png");
	this.cooldown[1][5] = loadImage("sprites\\unknown9_blue_cd.png");

	// load team specific UI images
	this.flagImgs[0] = loadImage("sprites\\redflag.png");
	this.flagImgs[1] = loadImage("sprites\\blueflag.png");
	this.topbarImgs[0] = loadImage("sprites\\topbar1.png");
	this.topbarImgs[1] = loadImage("sprites\\topbar2.png");
	
	// load buttons
	this.buttonImgs.unlit.build = loadImage("sprites\\hammerunlit.png");
	this.buttonImgs.lit.build = loadImage("sprites\\hammerlit.png");
	this.buttonImgs.unlit.menu = loadImage("sprites\\menuunlit.png");
	this.buttonImgs.lit.menu = loadImage("sprites\\menulit.png");
	this.buttonImgs.unlit.mute = loadImage("sprites\\muteunlit.png");
	this.buttonImgs.lit.mute = loadImage("sprites\\mutelit.png");
	this.buttonImgs.unlit.sound = loadImage("sprites\\soundunlit.png");
	this.buttonImgs.lit.sound = loadImage("sprites\\soundlit.png");
	
	// build unit buttons
	this.buildUnitImgs.frame = loadImage("sprites\\build\\buildframe.png");
	this.buildUnitImgs.unavailable[0] = loadImage("sprites\\build\\vampire_grey.png");
	this.buildUnitImgs.unlit[0] = loadImage("sprites\\build\\vampire_black.png");
	this.buildUnitImgs.lit[0] = loadImage("sprites\\build\\vampire_green.png");
	this.buildUnitImgs.unavailable[1] = loadImage("sprites\\build\\wolf_grey.png");
	this.buildUnitImgs.unlit[1] = loadImage("sprites\\build\\wolf_black.png");
	this.buildUnitImgs.lit[1] = loadImage("sprites\\build\\wolf_green.png");
	this.buildUnitImgs.unavailable[2] = loadImage("sprites\\build\\hunter_grey.png");
	this.buildUnitImgs.unlit[2] = loadImage("sprites\\build\\hunter_black.png");
	this.buildUnitImgs.lit[2] = loadImage("sprites\\build\\hunter_green.png");
	this.buildUnitImgs.unavailable[3] = loadImage("sprites\\build\\zombie_grey.png");
	this.buildUnitImgs.unlit[3] = loadImage("sprites\\build\\zombie_black.png");
	this.buildUnitImgs.lit[3] = loadImage("sprites\\build\\zombie_green.png");
	this.buildUnitImgs.unavailable[4] = loadImage("sprites\\build\\wizard_grey.png");
	this.buildUnitImgs.unlit[4] = loadImage("sprites\\build\\wizard_black.png");
	this.buildUnitImgs.lit[4] = loadImage("sprites\\build\\wizard_green.png");
	
	// guess unit buttons
	this.markUnitImgs.unlit[0] = loadImage("sprites\\mark\\vampire_unlit.png");
	this.markUnitImgs.lit[0] = loadImage("sprites\\mark\\vampire_lit.png");
	this.markUnitImgs.unlit[1] = loadImage("sprites\\mark\\wolf_unlit.png");
	this.markUnitImgs.lit[1] = loadImage("sprites\\mark\\wolf_lit.png");
	this.markUnitImgs.unlit[2] = loadImage("sprites\\mark\\hunter_unlit.png");
	this.markUnitImgs.lit[2] = loadImage("sprites\\mark\\hunter_lit.png");
	this.markUnitImgs.unlit[3] = loadImage("sprites\\mark\\zombie_unlit.png");
	this.markUnitImgs.lit[3] = loadImage("sprites\\mark\\zombie_lit.png");
	this.markUnitImgs.unlit[4] = loadImage("sprites\\mark\\wizard_unlit.png");
	this.markUnitImgs.lit[4] = loadImage("sprites\\mark\\wizard_lit.png");
	
	// get hit images
	this.getHitImgs.small[0][0] = loadImage("sprites\\gethit\\vampire_red_small_hit.png");
	this.getHitImgs.small[0][1] = loadImage("sprites\\gethit\\wolf_red_small_hit.png");
	this.getHitImgs.small[0][2] = loadImage("sprites\\gethit\\hunter_red_small_hit.png");
	this.getHitImgs.small[0][3] = loadImage("sprites\\gethit\\zombie_red_small_hit.png");
	this.getHitImgs.small[0][4] = loadImage("sprites\\gethit\\wizard_red_small_hit.png");
	this.getHitImgs.small[1][0] = loadImage("sprites\\gethit\\vampire_blue_small_hit.png");
	this.getHitImgs.small[1][1] = loadImage("sprites\\gethit\\wolf_blue_small_hit.png");
	this.getHitImgs.small[1][2] = loadImage("sprites\\gethit\\hunter_blue_small_hit.png");
	this.getHitImgs.small[1][3] = loadImage("sprites\\gethit\\zombie_blue_small_hit.png");
	this.getHitImgs.small[1][4] = loadImage("sprites\\gethit\\wizard_blue_small_hit.png");
	
	this.getHitImgs.big[0][0] = loadImage("sprites\\gethit\\vampire_red_big_hit.png");
	this.getHitImgs.big[0][1] = loadImage("sprites\\gethit\\wolf_red_big_hit.png");
	this.getHitImgs.big[0][2] = loadImage("sprites\\gethit\\hunter_red_big_hit.png");
	this.getHitImgs.big[0][3] = loadImage("sprites\\gethit\\zombie_red_big_hit.png");
	this.getHitImgs.big[0][4] = loadImage("sprites\\gethit\\wizard_red_big_hit.png");
	this.getHitImgs.big[1][0] = loadImage("sprites\\gethit\\vampire_blue_big_hit.png");
	this.getHitImgs.big[1][1] = loadImage("sprites\\gethit\\wolf_blue_big_hit.png");
	this.getHitImgs.big[1][2] = loadImage("sprites\\gethit\\hunter_blue_big_hit.png");
	this.getHitImgs.big[1][3] = loadImage("sprites\\gethit\\zombie_blue_big_hit.png");
	this.getHitImgs.big[1][4] = loadImage("sprites\\gethit\\wizard_blue_big_hit.png");
	
	// add terrain images
	CONSTANTS.thronTerrain.image = this.thronImg;
	CONSTANTS.flagTerrain.image = this.flagImg;
	CONSTANTS.resourceTerrain.image = this.resourceImg;
	CONSTANTS.heart = this.heartImg;
		
}