/**
* Client UI controls in browser platform.
*/ 

var mousemove = function(event) {  // mouse move event listener
	var x = event.pageX;
	var y = event.pageY;
	var offsetLeft = stage.getContainer().offsetLeft;
	var offsetTop = stage.getContainer().offsetTop;
	if (x < offsetLeft) {
		gameClientUI.camera.isMovingLeft = true;
	} else {
		gameClientUI.camera.isMovingLeft = false;
	}
	if (x > offsetLeft+CONSTANTS.width) {
		gameClientUI.camera.isMovingRight = true;
	} else {
		gameClientUI.camera.isMovingRight = false;
	}
	if (y < offsetTop) {
		gameClientUI.camera.isMovingUp = true;
	} else {
		gameClientUI.camera.isMovingUp = false;
	}
	if (y > offsetTop+CONSTANTS.height) {
		gameClientUI.camera.isMovingDown = true;
	} else {
		gameClientUI.camera.isMovingDown = false;
	}
};
document.addEventListener("mousemove", mousemove);

var contextmenu = function(event) { // right click event listener
	var x = event.pageX;
	var y = event.pageY;
	var offsetLeft = stage.getContainer().offsetLeft;
	var offsetTop = stage.getContainer().offsetTop;
	if (x >= offsetLeft && x <= offsetLeft+CONSTANTS.width && y >= offsetTop && y <= offsetTop+CONSTANTS.height) {
		event.preventDefault();
		gameClientUI.last_click_coord = null;
		gameClientUI.hexgrid.clientClearReachable();
		gameClientUI.hexgrid.clientClearAttackable();
		if(gameClientUI.guess){
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		gc.build = false;
		gc.toBuild = null;
		gc.hexgrid.clientClearBuildable();
	}
};
document.addEventListener('contextmenu', contextmenu);
this.contextmenu = contextmenu;

var keydown = function(event) { // keydown event listener
	if (event.keyCode == 37 || event.keyCode == 65) { // left
		gameClientUI.camera.isMovingLeft = true;
	} else if (event.keyCode == 39 || event.keyCode == 68) { // right
		gameClientUI.camera.isMovingRight = true;
	} else if (event.keyCode == 38 || event.keyCode == 87) { // up
		gameClientUI.camera.isMovingUp = true;
	} else if (event.keyCode == 40 || event.keyCode == 83) { // down
		gameClientUI.camera.isMovingDown = true;
	}
	if (event.keyCode == 49){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(0);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		if(gameClientUI.build){
			if(gameClientUI.resource >= CONSTANTS.cost[0]){
				gameClientUI.toBuild = 0;
				gameClientUI.hexgrid.clientMarkBuildable(gameClientUI.player);
			}
			gameClientUI.build = false;
		}
	}
	if (event.keyCode == 50){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(1);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		if(gameClientUI.build){
			if(gameClientUI.resource >= CONSTANTS.cost[1]){
				gameClientUI.toBuild = 1;
				gameClientUI.hexgrid.clientMarkBuildable(gameClientUI.player);
			}
			gameClientUI.build = false;
		}
	}
	if (event.keyCode == 51){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(2);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		if(gameClientUI.build){
			if(gameClientUI.resource >= CONSTANTS.cost[2]){
				gameClientUI.toBuild = 2;
				gameClientUI.hexgrid.clientMarkBuildable(gameClientUI.player);
			}
			gameClientUI.build = false;
		}
	}
	if (event.keyCode == 52){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(3);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		if(gameClientUI.build){
			if(gameClientUI.resource >= CONSTANTS.cost[3]){
				gameClientUI.toBuild = 3;
				gameClientUI.hexgrid.clientMarkBuildable(gameClientUI.player);
			}
			gameClientUI.build = false;
		}
	}
	if (event.keyCode == 53){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(4);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		if(gameClientUI.build){
			if(gameClientUI.resource >= CONSTANTS.cost[4]){
				gameClientUI.toBuild = 4;
				gameClientUI.hexgrid.clientMarkBuildable(gameClientUI.player);
			}
			gameClientUI.build = false;
		}
	}
	if (event.keyCode == 54){
		if(gameClientUI.guess){
			gameClientUI.hexgrid.getUnit(gameClientUI.guess).guess(5);
			gameClientUI.hexgrid.matrix[gameClientUI.guess.X][gameClientUI.guess.Y].guessing = false;
			gameClientUI.guess = null;
		}
		gameClientUI.build = false;
		gameClientUI.toBuild = null;
		gameClientUI.hexgrid.clientClearBuildable();
	}	
	if (event.keyCode == 81){
		gameClientUI.build = true;
		gameClientUI.toBuild = null;
		gameClientUI.hexgrid.clientClearReachable();
		gameClientUI.hexgrid.clientClearAttackable();
		gameClientUI.hexgrid.clientClearBuildable();
		gameClientUI.buildUnitGroup.setVisible(true);
	}
};
document.addEventListener('keydown', keydown);

var keyup = function(event) { // keyup event listener
	if (event.keyCode == 37 || event.keyCode == 65) { // left
		gameClientUI.camera.isMovingLeft = false;
	} else if (event.keyCode == 39 || event.keyCode == 68) { // right
		gameClientUI.camera.isMovingRight = false;
	} else if (event.keyCode == 38 || event.keyCode == 87) { // up
		gameClientUI.camera.isMovingUp = false;
	} else if (event.keyCode == 40 || event.keyCode == 83) { // down
		gameClientUI.camera.isMovingDown = false;
	}
};
document.addEventListener('keyup', keyup);