Enemy Unknown
===============

Beck, Frank, and Yi's Comp460 game.
The multiplayer feature is based on node.js and socket.io. See the usage below to install necessary modules.

## Usage
* Get node.js
* run `npm install` inside the cloned folder
* run `node app.js` inside the cloned folder
* Visit http://127.0.0.1:4004/